package entity;


public enum Direction {
    HAUT,
    BAS,
    GAUCHE,
    DROITE;
}
